package com.robin.blog.exception;

/**
 * @author robin
 * @version 1.0
 * @date 2021/12/13 9:57
 */

public class ServeException extends RuntimeException {
    public ServeException(String message) {
        super(message);
    }
}
